// Uncomment the next line to use precompiled headers
#include "pch.h"
// Uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"

// The global test environment setup and teardown
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  void SetUp() override
  {
    // Initialize random seed
    srand(time(nullptr));
  }

  void TearDown() override {}
};

// Create our test class to house shared data between tests
class CollectionTest : public ::testing::Test
{
protected:
  // Create a smart pointer to hold our collection
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  { 
    collection.reset(new std::vector<int>);
  }

  void TearDown() override
  {
    collection->clear();
    collection.reset(nullptr);
  }

  void add_entries(int count)
  {
    assert(count > 0);
    for (auto i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};

// Test that a collection is not null when created
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  ASSERT_TRUE(collection);
  ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created
TEST_F(CollectionTest, IsEmptyOnCreate)
{
  ASSERT_TRUE(collection->empty());
  ASSERT_EQ(collection->size(), 0);
}

// Test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
  add_entries(1);
  ASSERT_FALSE(collection->empty());
  ASSERT_EQ(collection->size(), 1);
}

// Test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);
}

// Test to verify that max_size is greater than or equal to size for various entry counts
TEST_F(CollectionTest, MaxSizeGreaterThanSize)
{
  std::vector<int> test_vector;
  ASSERT_GE(test_vector.max_size(), 0);
  add_entries(0);
  ASSERT_GE(test_vector.max_size(), test_vector.size());
  add_entries(1);
  ASSERT_GE(test_vector.max_size(), test_vector.size());
  add_entries(5);
  ASSERT_GE(test_vector.max_size(), test_vector.size());
  add_entries(10);
  ASSERT_GE(test_vector.max_size(), test_vector.size());
}

// Test to verify that capacity is greater than or equal to size for various entry counts
TEST_F(CollectionTest, CapacityGreaterThanSize)
{
  std::vector<int> test_vector;
  ASSERT_GE(test_vector.capacity(), 0);
  add_entries(0);
  ASSERT_GE(test_vector.capacity(), test_vector.size());
  add_entries(1);
  ASSERT_GE(test_vector.capacity(), test_vector.size());
  add_entries(5);
  ASSERT_GE(test_vector.capacity(), test_vector.size());
  add_entries(10);
  ASSERT_GE(test_vector.capacity(), test_vector.size());
}

// Test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesCollection)
{
  size_t original_size = collection->size();
  collection->resize(original_size + 5);
  ASSERT_GT(collection->size(), original_size);
}

// Test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesCollection)
{
  size_t original_size = collection->size();
  collection->resize(original_size + 5);
  collection->resize(original_size);
  ASSERT_EQ(collection->size(), original_size);
}

// Test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeToZero)
{
  add_entries(10);
  collection->resize(0);
  ASSERT_EQ(collection->size(), 0);
}

// Test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
  add_entries(5);
  collection->clear();
  ASSERT_TRUE(collection->empty());
}

// Test to verify erase(begin, end) erases the collection
TEST_F(CollectionTest, EraseRangeErasesCollection)
{
  add_entries(10);
  collection->erase(collection->begin(), collection->end());
  ASSERT_TRUE(collection->empty());
}

// Test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacity)
{
  size_t original_capacity = collection->capacity();
  collection->reserve(100);
  ASSERT_GE(collection->capacity(), original_capacity);
}

// Test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
TEST_F(CollectionTest, AtThrowsOutOfRange)
{
  collection->resize(5);
  EXPECT_THROW(collection->at(10), std::out_of_range);
}

// Custom positive and negative tests
TEST_F(CollectionTest, CustomPositiveTest)
{
  add_entries(10);
  ASSERT_EQ(collection->size(), 10);
  ASSERT_GE(collection->capacity(), 10); // Ensure capacity is sufficient
}

TEST_F(CollectionTest, CustomNegativeTest)
{
  // Attempt to access an element out of bounds
  collection->resize(5);
  EXPECT_THROW({
    try {
      int value = (*collection)[10]; // Accessing out of bounds
    } catch (const std::out_of_range& e) {
      throw; // Rethrow exception to be caught by EXPECT_THROW
    }
  }, std::out_of_range);
}
