// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>  // For std::string
#include <cstring> // For std::strncpy

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    const std::string account_number = "CharlieBrown42";
    char user_input[20]; // Buffer size for user input, including space for the null terminator

    std::cout << "Enter a value (up to 19 characters): ";
    
    // Read user input into a temporary string
    std::string temp_input;
    std::getline(std::cin, temp_input);

    // Ensure the string does not exceed the buffer size
    if (temp_input.size() >= sizeof(user_input)) {
        std::cout << "Input too long. Truncating to fit buffer size." << std::endl;
        temp_input = temp_input.substr(0, sizeof(user_input) - 1); // Keep only the first 19 characters
    }

    // Copy the truncated input into the user_input buffer and ensure it is null-terminated
    std::strncpy(user_input, temp_input.c_str(), sizeof(user_input) - 1);
    user_input[sizeof(user_input) - 1] = '\0';  // Ensure null termination

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;

    return 0;
}
